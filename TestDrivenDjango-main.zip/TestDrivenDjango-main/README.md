# TestDrivenDjango
This is code for a video series on Test Driven Development with the Django web franework.


# Run this code
```
git clone https://github.com/jod35/TestDrivenDjango
```

```
pip3 install -r requirements.txt
```

```
python3 manage.py runserver
```
